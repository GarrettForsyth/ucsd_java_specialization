/**
 * @author UCSD MOOC development team and YOU
 * 
 * A class which reprsents a graph of geographic locations
 * Nodes in the graph are intersections between 
 *
 */
package roadgraph;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.function.Consumer;

import geography.GeographicPoint;
import util.GraphLoader;

/**
 * @author UCSD MOOC development team and YOU
 * 
 * A class which represents a graph of geographic locations
 * Nodes in the graph are intersections between 
 *
 */
public class MapGraph {
    
    //Use an adjacent list because this is a 'sparse' graph
    //because in general each intersection should have 8 edges
    //connected to it or less.
    private HashSet<MapNode> intersections;
	
	/** 
	 * Create a new empty MapGraph 
	 */
	public MapGraph()
	{
	    intersections= new HashSet<MapNode>();
	}
	
	/**
	 * Get the number of vertices (road intersections) in the graph
	 * @return The number of vertices in the graph.
	 */
	public int getNumVertices()
	{
		return intersections.size();
	}
	
	/**
	 * Return the intersections, which are the vertices in this graph.
	 * @return The vertices in this graph as GeographicPoints
	 */
	public Set<GeographicPoint> getVertices()
	{
	    Set<GeographicPoint> vertices= new HashSet<>();
	    
	    //Iterate over the vertices, extract
	    //the GeograhpicPoint from each and add to list
	    for(MapNode mn : intersections){
	        vertices.add(mn.getPosition());
	    }
		return vertices;
	}
	
	/**
	 * Get the number of road segments in the graph
	 * @return The number of edges in the graph.
	 */
	public int getNumEdges()
	{
	    int count=0;
		//Iterate over reach vertex and count how many
        //edges are connected to it:
		for(MapNode mn : intersections){
		    count+= mn.getNeighbors().size();
		}
		return count;
	}

	/** Add a node corresponding to an intersection at a Geographic Point
	 * If the location is already in the graph or null, this method does 
	 * not change the graph.
	 * @param location  The location of the intersection
	 * @return true if a node was added, false if it was not (the node
	 * was already in the graph, or the parameter is null).
	 */
	public boolean addVertex(GeographicPoint location)
	{
	    if(location== null){return false;}
	    MapNode newVertex= new MapNode(location);

	    if(intersections.contains(newVertex)){
	        return false;
	    }
	    intersections.add(newVertex);
		return true;
	}
	
	/**
	 * Adds a directed edge to the graph from pt1 to pt2.  
	 * Precondition: Both GeographicPoints have already been added to the graph
	 * @param from The starting point of the edge
	 * @param to The ending point of the edge
	 * @param roadName The name of the road
	 * @param roadType The type of the road
	 * @param length The length of the road, in km
	 * @throws IllegalArgumentException If the points have not already been
	 *   added as nodes to the graph, if any of the arguments is null,
	 *   or if the length is less than 0.
	 */
	public void addEdge(GeographicPoint from, GeographicPoint to, String roadName,
			String roadType, double length) throws IllegalArgumentException {
	    if(from==null || to== null || roadName== null || roadType== null || length < 0){
            throw new IllegalArgumentException("addEdge has invalid arguements.");
        }
	    //initialize:
	    MapNode fromNode= new MapNode(from);
	    MapNode toNode= new MapNode(to);    
	    //ensure nodes are part of the hashset
	    if(!intersections.contains(toNode) || !intersections.contains(fromNode)){
	        throw new IllegalArgumentException("Intersections does not contain"
	                                        + " either start or end coordinate.");
	    }
	    	    
	    //iterate over the hashSet and get pointers for the 'to' and 'from'
	    //MapNodes and then add an edge between them.
	    //note this takes O(n) time so if adding a lot of edges, should
	    //change data structure from hashset to something else.
	    //since this is a sparse graph, there should be relatively few edges 
	    
        List<MapNode> nodes= new ArrayList<>(2);
        nodes.add(fromNode);
        nodes.add(toNode);
        //Iterate over using helper method hashset and create
        // pointers to start and goal nodes:
        List<MapNode> pointers= getPointers(nodes);
        //set pointers appropriately (since list comes back unordered):
        if(pointers.get(0).equals(fromNode)){ 
            fromNode= pointers.get(0);
            toNode= pointers.get(1);
        }
        else{
            fromNode= pointers.get(1);
            toNode= pointers.get(0);
        }
	    //creates the new edge and adds it to the node using the pointer
	    MapEdge newEdge= new MapEdge(toNode, fromNode, roadName, roadType);  
	    fromNode.addEdge(toNode);    		
	}
	

	/** Find the path from start to goal using breadth first search
	 * 
	 * @param start The starting location
	 * @param goal The goal location
	 * @return The list of intersections that form the shortest (unweighted)
	 *   path from start to goal (including both start and goal).
	 */
	public List<GeographicPoint> bfs(GeographicPoint start, GeographicPoint goal) {
		// Dummy variable for calling the search algorithms
        Consumer<GeographicPoint> temp = (x) -> {};
        return bfs(start, goal, temp);
	}
	
	/** Find the path from start to goal using breadth first search
	 * 
	 * @param start The starting location
	 * @param goal The goal location
	 * @param nodeSearched A hook for visualization.  See assignment instructions for how to use it.
	 * @return The list of intersections that form the shortest (unweighted)
	 *   path from start to goal (including both start and goal).
	 */
	public List<GeographicPoint> bfs(GeographicPoint start, 
			 					     GeographicPoint goal, Consumer<GeographicPoint> nodeSearched)
	{
	    //Validate input:
	    if(start== null || goal== null){
	        return null;
	    }
	    	    
	    //Create nodes from geographical points for comparison purposes
	    //(two MapNode objects are equal if they have the same GeographicPoint)
	    MapNode startNode= new MapNode(start);
	    MapNode goalNode= new MapNode(goal);
	    List<MapNode> nodes= new ArrayList<>(2);
	    nodes.add(startNode);
	    nodes.add(goalNode);
	    //Iterate over using helper method hashset and create
	    // pointers to start and goal nodes:
	    List<MapNode> pointers= getPointers(nodes);
	    //set pointers appropriately (since list comes back unordered):
	    if(pointers.get(0).equals(startNode)){ 
	        startNode= pointers.get(0);
	        goalNode= pointers.get(1);
	    }
	    else{
	        startNode= pointers.get(1);
	        goalNode= pointers.get(0);
	    }
	    	          
        //returns if either node wasn't found in the hashset
	    if(!intersections.contains(startNode) || !intersections.contains(goalNode)){
	        return null;
	    }
	    
	    //Initialize:	    
	    Queue<MapNode> toCheck= new LinkedList<MapNode>();
	    HashSet<MapNode> visited= new HashSet();
	    Map<MapNode, ArrayList<MapNode>> parentMap= new HashMap<>();
	    toCheck.add(startNode);
	    visited.add(startNode);
	    	    
	    //Search:
	    if(!(createParentMap(toCheck, visited, parentMap, goal, nodeSearched))){
	        return null;
	    }
	    
	    //Reconstruct path:
	    LinkedList<MapNode> route= reconstructPath(startNode,goalNode, parentMap);
	        
	    //return a GeographicPoint list
	    //Initialize to route's size to prevent 'resizing'
	    List<GeographicPoint> returnList= new ArrayList<>(route.size());
	    for(MapNode mn : route){
	        returnList.add(mn.getPosition());
	    }
	    return returnList;
	    
    	    	    		
		// Hook for visualization.  See writeup.
		//nodeSearched.accept(next.getLocation());

	}
	/**
     * Helper method that returns a list of pointers to the
     * MapNodes in intersection. These are found by comparing 
     * from the list argument input.
     * @param A list of MapNodes to compare with
     * @return The list of MapNodes in the intersections hashset
     **/
	private List<MapNode> getPointers(List<MapNode> input){
	    List<MapNode> listOfPointers= new ArrayList<>();
	    
	    //counter to exit early if possible
	    int exitCount=0; 
        Iterator<MapNode> intersectionsIterator= intersections.iterator();
        while(intersectionsIterator.hasNext()){
            MapNode intersection= intersectionsIterator.next();
            //Checks each item in list to see if contained in intersections
            for(MapNode mn : input){
                if(intersection.equals(mn)){
                    //if so, add to the list of pointers
                    listOfPointers.add(intersection);
                    exitCount++;
                }
            }
            if(exitCount==input.size()){break;}
        }
        return listOfPointers;
	}
	/**
     * Helper method that returns the route from
     * the start to the goal.
     * @param MapNode corresponding to the start of the search
     * @param MapNode corresponding to the end of the search
     * @param hashMap of nodes' and their parents
     * @return a linked list of MapNodes corresponding to the shortest
     * path from the start node to the finish node.
     **/
	private LinkedList<MapNode> reconstructPath(MapNode start, MapNode goal, 
	        Map<MapNode, ArrayList<MapNode>> parentMap)
	{	            
        LinkedList<MapNode> path = new LinkedList<MapNode>();
        MapNode curr = goal;
        while (curr != start) {
            path.addFirst(curr);
            curr = parentMap.get(curr).get(0);
        }
        path.addFirst(start);
        return path;
	}
	
	/**
	 * Helper method that searches for path from creating a parentMap
	 * hashmap on the way (which is used later).
	 * @param Queue of MapNodes to check.
     * @param HashSet tracking the nodes already visited
     * @param map of a node to a list of it's parent's nodes (parent nodes
     * are nodes that have an edge directed to this node)
     * @param a GeographicPoint used to create a goal MapNode
     * @return False if no path is found, true otherwise.
	 **/
	private boolean createParentMap(Queue<MapNode> toCheck,HashSet<MapNode> visited, 
	        Map<MapNode, ArrayList<MapNode>> parentMap, GeographicPoint goal, 
	        Consumer<GeographicPoint> nodeSearched)
	{
	    MapNode goalNode= new MapNode(goal);
	    MapNode curr;
	    while(!toCheck.isEmpty()){
            curr= toCheck.remove();
            //check if goal has been reached:
            if(curr.equals(goalNode)){
                return true;
            }
            //add all unvisited neighbors to the queue:
            for(MapEdge me : curr.getNeighbors()){
                MapNode mn= me.getEndNode();
                if(!visited.contains(mn)){
                    nodeSearched.accept(mn.getPosition());
                    visited.add(mn);
                    //if not on parent map, add it:
                    if(!parentMap.containsKey(mn)){
                        parentMap.put(mn, new ArrayList<MapNode>());
                    }
                    //add curr as parent:
                    parentMap.get(mn).add(curr);
                    //add gp to the queue:
                    toCheck.add(mn);              
                }
            }
        }
        return false;
	}
	
	/** Find the path from start to goal using Dijkstra's algorithm
	 * 
	 * @param start The starting location
	 * @param goal The goal location
	 * @return The list of intersections that form the shortest path from 
	 *   start to goal (including both start and goal).
	 */
	public List<GeographicPoint> dijkstra(GeographicPoint start, GeographicPoint goal) {
		// Dummy variable for calling the search algorithms
		// You do not need to change this method.
        Consumer<GeographicPoint> temp = (x) -> {};
        return dijkstra(start, goal, temp);
	}
	
	/** Find the path from start to goal using Dijkstra's algorithm
	 * 
	 * @param start The starting location
	 * @param goal The goal location
	 * @param nodeSearched A hook for visualization.  See assignment instructions for how to use it.
	 * @return The list of intersections that form the shortest path from 
	 *   start to goal (including both start and goal).
	 */
	public List<GeographicPoint> dijkstra(GeographicPoint start, 
										  GeographicPoint goal, Consumer<GeographicPoint> nodeSearched)
	{
		// TODO: Implement this method in WEEK 4

		// Hook for visualization.  See writeup.
		//nodeSearched.accept(next.getLocation());
		
		return null;
	}

	/** Find the path from start to goal using A-Star search
	 * 
	 * @param start The starting location
	 * @param goal The goal location
	 * @return The list of intersections that form the shortest path from 
	 *   start to goal (including both start and goal).
	 */
	public List<GeographicPoint> aStarSearch(GeographicPoint start, GeographicPoint goal) {
		// Dummy variable for calling the search algorithms
        Consumer<GeographicPoint> temp = (x) -> {};
        return aStarSearch(start, goal, temp);
	}
	
	/** Find the path from start to goal using A-Star search
	 * 
	 * @param start The starting location
	 * @param goal The goal location
	 * @param nodeSearched A hook for visualization.  See assignment instructions for how to use it.
	 * @return The list of intersections that form the shortest path from 
	 *   start to goal (including both start and goal).
	 */
	public List<GeographicPoint> aStarSearch(GeographicPoint start, 
											 GeographicPoint goal, Consumer<GeographicPoint> nodeSearched)
	{
		// TODO: Implement this method in WEEK 4
		
		// Hook for visualization.  See writeup.
		//nodeSearched.accept(next.getLocation());
		
		return null;
	}

	
	
	public static void main(String[] args)
	{
		System.out.print("Making a new map...");
		MapGraph firstMap = new MapGraph();
		System.out.print("DONE. \nLoading the map...");
		GraphLoader.loadRoadMap("data/testdata/simpletest.map", firstMap);
		System.out.println("DONE.");
		
		// You can use this method for testing.
		GeographicPoint start= new GeographicPoint(1.0,1.0);
		GeographicPoint goal= new GeographicPoint(8.0,-1.0);
		
		System.out.println(firstMap.getNumEdges());
		System.out.println(firstMap.getNumVertices());
		
		List<GeographicPoint> testBfs= firstMap.bfs(start,goal);
		for(GeographicPoint gp : testBfs){
		    System.out.println(gp);
		}
		
		
		/* Here are some test cases you should try before you attempt 
		 * the Week 3 End of Week Quiz, EVEN IF you score 100% on the 
		 * programming assignment.
		 */
		/*
		MapGraph simpleTestMap = new MapGraph();
		GraphLoader.loadRoadMap("data/testdata/simpletest.map", simpleTestMap);
		
		GeographicPoint testStart = new GeographicPoint(1.0, 1.0);
		GeographicPoint testEnd = new GeographicPoint(8.0, -1.0);
		
		System.out.println("Test 1 using simpletest: Dijkstra should be 9 and AStar should be 5");
		List<GeographicPoint> testroute = simpleTestMap.dijkstra(testStart,testEnd);
		List<GeographicPoint> testroute2 = simpleTestMap.aStarSearch(testStart,testEnd);
		
		
		MapGraph testMap = new MapGraph();
		GraphLoader.loadRoadMap("data/maps/utc.map", testMap);
		
		// A very simple test using real data
		testStart = new GeographicPoint(32.869423, -117.220917);
		testEnd = new GeographicPoint(32.869255, -117.216927);
		System.out.println("Test 2 using utc: Dijkstra should be 13 and AStar should be 5");
		testroute = testMap.dijkstra(testStart,testEnd);
		testroute2 = testMap.aStarSearch(testStart,testEnd);
		
		
		// A slightly more complex test using real data
		testStart = new GeographicPoint(32.8674388, -117.2190213);
		testEnd = new GeographicPoint(32.8697828, -117.2244506);
		System.out.println("Test 3 using utc: Dijkstra should be 37 and AStar should be 10");
		testroute = testMap.dijkstra(testStart,testEnd);
		testroute2 = testMap.aStarSearch(testStart,testEnd);
		*/
		
		
		/* Use this code in Week 3 End of Week Quiz */
		/*MapGraph theMap = new MapGraph();
		System.out.print("DONE. \nLoading the map...");
		GraphLoader.loadRoadMap("data/maps/utc.map", theMap);
		System.out.println("DONE.");

		GeographicPoint start = new GeographicPoint(32.8648772, -117.2254046);
		GeographicPoint end = new GeographicPoint(32.8660691, -117.217393);
		
		
		List<GeographicPoint> route = theMap.dijkstra(start,end);
		List<GeographicPoint> route2 = theMap.aStarSearch(start,end);

		*/
		
	}
	
}
