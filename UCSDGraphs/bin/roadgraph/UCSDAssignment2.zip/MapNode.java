package roadgraph;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import geography.GeographicPoint;

/**
 * MapeNode.java
 * 
 * A class to represent a Node in the MapGraph.
 */

public class MapNode {
    private List<MapEdge> neighbors;
    private GeographicPoint position;
    
    /*
     * Constructor for no neighbors
     */
    public MapNode(GeographicPoint loc){
        if(loc== null){
            throw new IllegalArgumentException("Cannont instantiate with null location.");
        }
        position= loc;
        neighbors= new ArrayList<MapEdge>();
    }
    
    /*
     * Getter for position:
     */
    public GeographicPoint getPosition(){
        return this.position;
    }
    
    /*
     * Getter for neighbors:
     */
    public List<MapEdge> getNeighbors(){
        return  neighbors;
    }
    public List<MapNode> getNodeNeighbors(){
        List<MapNode> nodeNeighbors= new ArrayList<>(neighbors.size());
        for(MapEdge me : neighbors){
            nodeNeighbors.add(me.getEndNode());
        }
        return nodeNeighbors;
    }
    
    /*
     * Add edge of various flavours:
     */
    public void addEdge(MapNode neighborLocation){
        MapEdge newEdge= new MapEdge(this, neighborLocation);
        if(!neighbors.contains(newEdge)){
            neighbors.add(newEdge);
        }
        return;
    }
    public void addEdge(MapEdge newEdge){
        if(!neighbors.contains(newEdge)){
            neighbors.add(newEdge);
        }
        return;
    }
    
    public void addEdge(MapNode neighborNode, String streetName, String roadType){
        MapEdge newEdge= new MapEdge(this,
                         neighborNode, streetName, roadType);
        if(!neighbors.contains(newEdge)){
            neighbors.add(newEdge);
        }
        return;
    }
    
    /*
     * Two MapNodes are equal if they are at the same position.
     * Equals to method and hashCode() method:
     */
    public boolean equals(Object o) {
        
        if (o instanceof MapNode) {
          MapNode mn= (MapNode) o;
          if (this.position.equals(mn.position)) return true;
        }
        return false;
        
     }
    
    public int hashCode() {
        return Objects.hash(position);
    }
    
    /*
     * toString method:
     */
    public String toString() {

        
       String str= "Map Node Position: " + position.toString();
       return str;
        
    }
    
    
    
}
